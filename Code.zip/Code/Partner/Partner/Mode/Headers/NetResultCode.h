//
//  ErrorCode.h
//  QianFangGuJie
//
//  Created by kinghy on 15/4/6.
//  Copyright (c) 2015年 余龙. All rights reserved.
//

#ifndef QianFangGuJie_ErrorCode_h
#define QianFangGuJie_ErrorCode_h

//简单的将数字转成字符串的方法
#define code2str(code) [NSString stringWithFormat:@"%d",code]

//登陆相关请求
#define NET_SUCCESS_CODE                    0            //请求成功


#endif
