//
//  ProductPanKouMock.h
//  QianFangGuJie
//
//  Created by 余龙 on 15/1/13.
//  Copyright (c) 2015年 余龙. All rights reserved.
//
//盘口

@interface ProductPanKouParam : AppParam

/**产品代码*/
@property (nonatomic,copy) NSString *code;

@end
