//
//  MarketParam.h
//  Partner
//
//  Created by  rjt on 15/11/17.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "AppParam.h"

@interface MarketParam : AppParam

@end
