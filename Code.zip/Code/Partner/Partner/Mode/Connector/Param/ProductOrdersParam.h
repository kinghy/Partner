//
//  ProductOrdersParam.h
//  Partner
//
//  Created by  rjt on 15/11/25.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "AppParam.h"

@interface ProductOrdersParam : AppParam
@property (strong, nonatomic)  NSString *contractId;
@end
