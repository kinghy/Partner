//
//  OrdersSellEntity.m
//  Partner
//
//  Created by  rjt on 15/11/25.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "OrdersSellEntity.h"

@implementation OrdersSellEntity

@end
