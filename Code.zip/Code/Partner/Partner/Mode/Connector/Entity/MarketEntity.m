//
//  MarketEntity.m
//  Partner
//
//  Created by  rjt on 15/11/17.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "MarketEntity.h"

@implementation MarketEntity

@end

@implementation MarketRecordsEntity

@end