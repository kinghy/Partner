//
//  ProductEntity.m
//  Partner
//
//  Created by kinghy on 15/10/2.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "ProductEntity.h"

@implementation ProductEntity

@end
