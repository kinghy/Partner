//
//  CPBStockEntity.m
//  CaoPanBao
//
//  Created by 余龙 on 14/10/30.
//  Copyright (c) 2014年 weihui. All rights reserved.
//

#import "StockEntity.h"

@implementation StockEntity
-(void)dealloc{
    DDLogInfo(@"dealloc stockName = %@",self.stockName);
}
@end
