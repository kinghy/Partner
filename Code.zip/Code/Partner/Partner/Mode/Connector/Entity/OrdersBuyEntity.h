//
//  OrdersBuyEntity.h
//  Partner
//
//  Created by  rjt on 15/11/19.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "AppEntity.h"

@interface OrdersBuyEntity : AppEntity
@property (nonatomic,strong) NSString* ID;
@end
