//
//  ContractsEntity.m
//  Partner
//
//  Created by  rjt on 15/11/4.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "ContractsEntity.h"

@implementation ContractsEntity

@end

@implementation ContractsRecordsEntity

@end