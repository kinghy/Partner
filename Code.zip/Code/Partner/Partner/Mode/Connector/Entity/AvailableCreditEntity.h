//
//  AvailableCreditEntity.h
//  Partner
//
//  Created by  rjt on 15/11/19.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "AppEntity.h"

@interface AvailableCreditEntity : AppEntity
@property (strong,nonatomic) NSString* availableCredit;
@end
