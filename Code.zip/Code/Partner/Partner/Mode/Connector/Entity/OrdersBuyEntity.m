//
//  OrdersBuyEntity.m
//  Partner
//
//  Created by  rjt on 15/11/19.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "OrdersBuyEntity.h"

@implementation OrdersBuyEntity

@end
