//
//  AuthenticateEntity.m
//  Partner
//
//  Created by  rjt on 15/10/28.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "AuthenticateEntity.h"

@implementation AuthenticateEntity

@end
