//
//  ContractAlert.m
//  Partner
//
//  Created by  rjt on 15/10/14.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "ContractAlert.h"

@implementation ContractAlert

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
