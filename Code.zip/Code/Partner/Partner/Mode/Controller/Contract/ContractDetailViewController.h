//
//  ContractDetailViewController.h
//  Partner
//
//  Created by  rjt on 15/10/13.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "EFBaseViewController.h"

@interface ContractDetailViewController : EFBaseViewController
- (IBAction)createClicked:(id)sender;

@end
