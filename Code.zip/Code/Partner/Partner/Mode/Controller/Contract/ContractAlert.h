//
//  ContractAlert.h
//  Partner
//
//  Created by  rjt on 15/10/14.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ContractAlert : UIView
@property (weak, nonatomic) IBOutlet UIImageView *img;
@property (weak, nonatomic) IBOutlet UILabel *label;

@end
