//
//  STOProductSellMarketBll.h
//  Partner
//
//  Created by  rjt on 15/11/25.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "STOProductMarketBll.h"

@interface STOProductSellMarketBll : STOProductMarketBll

@end
