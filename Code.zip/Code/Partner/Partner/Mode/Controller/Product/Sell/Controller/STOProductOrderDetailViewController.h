//
//  STOProductOrderDetailViewController.h
//  Partner
//
//  Created by  rjt on 15/11/30.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "EFScrollViewController.h"

@interface STOProductOrderDetailViewController : EFScrollViewController

@end
