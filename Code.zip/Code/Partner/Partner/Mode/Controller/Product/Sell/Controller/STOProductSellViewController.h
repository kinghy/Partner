//
//  STOProductSellViewController.h
//  Partner
//
//  Created by  rjt on 15/11/25.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "EFBaseViewController.h"

@interface STOProductSellViewController : EFBaseViewController
@property (weak, nonatomic) IBOutlet EFTableView *mainTable;
@end
