//
//  STOProductSellOrderViewController.h
//  Partner
//
//  Created by  rjt on 15/11/26.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "EFBaseViewController.h"

@interface STOProductSellOrderViewController : EFBaseViewController
@property (weak, nonatomic) IBOutlet EFTableView *pTable;
@end
