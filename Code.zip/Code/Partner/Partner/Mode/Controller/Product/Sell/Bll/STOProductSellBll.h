//
//  STOProductSellBll.h
//  Partner
//
//  Created by  rjt on 15/11/13.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "EFBll.h"

@interface STOProductSellBll : EFBll<UITableViewDataSource,UITableViewDelegate>

@end
