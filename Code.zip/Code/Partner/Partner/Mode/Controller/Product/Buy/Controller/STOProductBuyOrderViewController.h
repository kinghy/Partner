//
//  STOProductBuyOrderViewController.h
//  Partner
//
//  Created by  rjt on 15/10/28.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "EFBaseViewController.h"

@interface STOProductBuyOrderViewController : EFBaseViewController
@property (weak, nonatomic) IBOutlet EFTableView *pTable;

@end
