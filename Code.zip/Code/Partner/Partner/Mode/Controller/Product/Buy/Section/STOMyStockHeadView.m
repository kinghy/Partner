//
//  STOMyStockHeadView.m
//  QianFangGuJie
//
//  Created by tongshangren on 15/8/19.
//  Copyright (c) 2015年 JYZD. All rights reserved.
//

#import "STOMyStockHeadView.h"

@implementation STOMyStockHeadView

- (void)awakeFromNib {
    // Initialization code
}


@end
