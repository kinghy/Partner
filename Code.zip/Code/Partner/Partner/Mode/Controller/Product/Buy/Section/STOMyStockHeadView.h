//
//  STOMyStockHeadView.h
//  QianFangGuJie
//
//  Created by tongshangren on 15/8/19.
//  Copyright (c) 2015年 JYZD. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface STOMyStockHeadView : UIView


@end
