//
//  STOProductFreeStyleSection.m
//  Partner
//
//  Created by  rjt on 15/11/12.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "STOProductFreeStyleSection.h"

@implementation STOProductFreeStyleSection
-(void)awakeFromNib{
//    self.translatesAutoresizingMaskIntoConstraints = NO;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
