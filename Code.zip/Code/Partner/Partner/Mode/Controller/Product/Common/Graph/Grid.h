//
//  Grid.h
//  chart
//
//  Created by  rjt on 15/5/27.
//  Copyright (c) 2015年 JYZD. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <UIKit/UIKit.h>


@interface Grid : NSObject

@property float price;
@property float percent;
@property long x_grid;

-(CGPoint)getPointWithBasePoint:(CGPoint)bp multWidth:(float)mw  multHeight:(float)mh;//获取中心点坐标
//-(CGPoint)getOriginWithOrigin:(CGPoint)point width:(CGFloat)w hieght:(CGFloat)h  scaleOrigin:(CGPoint)scalepoint;//获取左上点坐标
//-(CGPoint)getOriginWithOrigin:(CGPoint)point width:(CGFloat)w hieght:(CGFloat)h;//获取原始左上点坐标

@end
