//
//  PersonalBll.h
//  Partner
//
//  Created by kinghy on 15/12/20.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "EFBll.h"

@interface PersonalBll : EFBll

@end
