//
//  PartnerBll.h
//  Partner
//
//  Created by kinghy on 15/10/1.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "EFBll.h"
#import "PartnerViewModel.h"
@interface PartnerBll : EFBll

@end
