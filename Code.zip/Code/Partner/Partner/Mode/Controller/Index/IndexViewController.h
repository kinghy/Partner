//
//  IndexViewController.h
//  EasyFrame
//
//  Created by  rjt on 15/9/24.
//  Copyright © 2015年 交易支点. All rights reserved.
//

#import "EFBaseViewController.h"

@interface IndexViewController : EFBaseViewController

@end
