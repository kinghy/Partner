//
//  FilterListSection.m
//  Partner
//
//  Created by  rjt on 15/10/14.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "FilterListSection.h"

@implementation FilterListSection

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end


@implementation FilterInputSection

/*
 // Only override drawRect: if you perform custom drawing.
 // An empty implementation adversely affects performance during animation.
 - (void)drawRect:(CGRect)rect {
 // Drawing code
 }
 */

@end