//
//  FilterListBll.h
//  Partner
//
//  Created by  rjt on 15/10/14.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "EFBll.h"

@interface FilterListBll : EFBll

@end
