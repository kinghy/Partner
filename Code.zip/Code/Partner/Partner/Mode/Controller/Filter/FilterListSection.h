//
//  FilterListSection.h
//  Partner
//
//  Created by  rjt on 15/10/14.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "EFSection.h"

@interface FilterListSection : EFSection
@property (weak, nonatomic) IBOutlet UILabel *label;
@property (weak, nonatomic) IBOutlet UIImageView *image;

@end

@interface FilterInputSection : EFSection

@end