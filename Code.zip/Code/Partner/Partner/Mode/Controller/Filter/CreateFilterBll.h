//
//  CreateFilterBll.h
//  Partner
//
//  Created by kinghy on 15/10/4.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "FilterBll.h"

@interface CreateFilterBll : FilterBll

@end
