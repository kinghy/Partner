//
//  FilterBll.h
//  Partner
//
//  Created by kinghy on 15/10/2.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import "EFBll.h"

@interface FilterBll : EFBll

@end
