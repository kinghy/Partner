//
//  AppDelegate.h
//  EasyFrame
//
//  Created by kinghy on 15/6/7.
//  Copyright (c) 2015年 交易支点. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) UINavigationController *nav;
@end

