//
//  EFBaseManager.m
//  EasyFrame
//
//  Created by  rjt on 15/6/16.
//  Copyright (c) 2015年 交易支点. All rights reserved.
//

#import "EFBaseManager.h"
@implementation EFBaseManager
-(void)dealloc{
    show_dealloc_info(self);
}
@end

