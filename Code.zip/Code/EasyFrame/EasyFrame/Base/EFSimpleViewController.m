//
//  EFSimpleViewController.m
//  EasyFrame
//
//  Created by  rjt on 16/1/13.
//  Copyright © 2016年 Kinghy. All rights reserved.
//

#import "EFSimpleViewController.h"

@implementation EFSimpleViewController
- (void)viewDidLoad {
    [super viewDidLoad];
    [self initAdaptor];
}

-(void)initAdaptor{

}
@end
