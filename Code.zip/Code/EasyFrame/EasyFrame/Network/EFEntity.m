//
//  EFEntity.m
//  EasyFrame
//
//  Created by  rjt on 15/6/9.
//  Copyright (c) 2015年 交易支点. All rights reserved.
//

#import "EFEntity.h"

@implementation EFEntity
+(instancetype)entity{
    return [[self alloc] init];
}

-(void)dealloc{
//    show_dealloc_info(self);
}

@end
