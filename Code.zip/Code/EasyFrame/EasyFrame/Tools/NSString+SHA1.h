//
//  NSString+MD5.h
//  md5
//
//  Created by  rjt on 15/4/3.
//  Copyright (c) 2015年  rjt. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (SHA1)
//- (NSString *) md5;
- (NSString *) sha1;
//- (NSString *) sha1_base64;
//- (NSString *) md5_base64;
//- (NSString *) base64;

@end
