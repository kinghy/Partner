//
//  UIView+RemoveSubviews.h
//  Partner
//
//  Created by  rjt on 15/10/27.
//  Copyright © 2015年 Kinghy. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface UIView (RemoveSubviews)
-(void)removeAllSubviews;//移除所有子元素
@end
