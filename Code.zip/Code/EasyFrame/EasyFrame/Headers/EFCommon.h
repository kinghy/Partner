//
//  Common.h
//  EasyFrame
//
//  Created by kinghy on 15/6/7.
//  Copyright (c) 2015年 交易支点. All rights reserved.
//

#ifndef EasyFrame_Common_h
#define EasyFrame_Common_h



#ifdef DEBUG
static const int ddLogLevel = DDLogLevelVerbose;
#else
static const int ddLogLevel = DDLogLevelOff;
#endif

#endif
